# -*- coding: utf-8 -*-
"""Step 6: analyses added in revision.

  python step6_revision.py prep      # 主样本 + 文体标记（缓存 main_rev.pkl）
  python step6_revision.py event     # 事件研究、事前趋势检验、相对幅度界（Rambachan & Roth 2023 思路）、TOST、Holm
  python step6_revision.py comp      # 构成平衡表 + 新增稳健性行 + 文体拆分
  python step6_revision.py ri        # 1,000 次随机化推断 + 逐月安慰剂分布 + 逐个剔除经济学家
  python step6_revision.py terms     # 词表逐词剔除、领导人称谓与政策口号拆分
  python step6_revision.py wcb       # 新结果的 wild cluster bootstrap p 值
结果统一写入 rev_results.json。
"""
import sys, os, re, json, warnings, importlib.util
import numpy as np, pandas as pd, pyfixest as pf
from scipy import stats
warnings.filterwarnings('ignore')
_spec = importlib.util.spec_from_file_location('s5', 'step5_llm.py'); s5 = importlib.util.module_from_spec(_spec)
_argv = sys.argv; sys.argv = ['x']; _spec.loader.exec_module(s5); sys.argv = _argv

EVENT = pd.Timestamp('2024-12-18')
OUT = 'rev_results.json'
CORE = ['tone_yao', 'r_pess', 'r_offi']
DISC = '风险提示'                                                    # 券商研报衍生文本的标志
INTERVIEW = '专访|访谈|对话|演讲|发言|致辞|采访|论坛|峰会'            # 标题中的访谈、演讲类标志
STOCK = '股市|A股|股票|牛市|熊市|港股|美股|大盘|股指|上证|沪指|资本市场'  # 标题中的股市关键词
SEED = 2026


def save(key, val):
    r = json.load(open(OUT, encoding='utf-8')) if os.path.exists(OUT) else {}
    r[key] = val
    json.dump(r, open(OUT, 'w', encoding='utf-8'), indent=1, ensure_ascii=False, default=float)


def load_all():
    if os.path.exists('main_rev.pkl'):
        return pd.read_pickle('main_rev.pkl')
    df = s5.load_corpus()
    d = df[(df['aff'] != 'AMBIG') & (df['ntok'] >= 200) & (df['date'] >= '2019-01-01')].copy()
    d['treat'] = (d['aff'] == 'SEC').astype(int)
    d['post'] = (d['date'] >= EVENT).astype(int)
    d['tp'] = d['treat'] * d['post']
    d['ym'] = d['date'].dt.strftime('%Y-%m')
    d['report'] = d['text'].str.contains(DISC).astype(int)
    d['interview'] = d['标题'].str.contains(INTERVIEW).astype(int)
    d['stock'] = d['标题'].str.contains(STOCK).astype(int)
    d['k'] = np.floor((d['date'] - EVENT).dt.days / 182.5).astype(int)
    d = d.reset_index(drop=True)
    d.to_pickle('main_rev.pkl')
    return d


def main(d=None):
    d = load_all() if d is None else d
    return d[d['date'] >= '2021-01-01'].reset_index(drop=True)


def est(z, y, extra='', w=None, ctrl=True):
    z = z[z[y].notna()].reset_index(drop=True)
    rhs = 'tp' + (' + lntok' if ctrl and y != 'lntok' else '') + extra
    m = pf.feols(f'{y} ~ {rhs} | name + ym', data=z, vcov={'CRV1': 'name'}, weights=w)
    t = m.tidy().loc['tp']
    return dict(b=float(t['Estimate']), se=float(t['Std. Error']), p=float(t['Pr(>|t|)']), n=int(m._N),
                k=int(z['name'].nunique()))


def pre_sd(z, y):
    return float(z.loc[z['post'] == 0, y].std())


def holm(pdict):
    ps = sorted((v, k) for k, v in pdict.items()); run = 0; out = {}
    for i, (p, k) in enumerate(ps):
        run = max(run, min(1.0, (len(ps) - i) * p)); out[k] = run
    return out


# ------------------------------------------------------------------ event study, bounds, TOST, Holm
def cmd_event():
    d = main(); res = {}
    d['kk'] = d['k'].clip(lower=-8, upper=2)
    ks = sorted(d['kk'].unique())
    for k in ks:
        if k != -1:
            d[f'e{k + 10}'] = ((d['kk'] == k) & (d['treat'] == 1)).astype(int)
    rhs = ' + '.join(f'e{k + 10}' for k in ks if k != -1)
    G = d['name'].nunique()
    for y in CORE:
        m = pf.feols(f'{y} ~ {rhs} + lntok | name + ym', data=d, vcov={'CRV1': 'name'})
        cf = m.coef(); names = list(cf.index); V = m._vcov
        pre = [f'e{k + 10}' for k in ks if k < -1]; post = [f'e{k + 10}' for k in ks if k >= 0]
        ip = [names.index(c) for c in pre]; iq = [names.index(c) for c in post]
        bp = cf[pre].values; Vp = V[np.ix_(ip, ip)]
        W = float(bp @ np.linalg.inv(Vp) @ bp)
        coefs = {int(k): (0.0 if k == -1 else float(cf[f'e{k + 10}'])) for k in ks}
        # 相对幅度界：通知后各期偏离的变化不超过 M 乘以事前相邻期最大变化
        pre_path = [coefs[k] for k in ks if k <= -1]
        B = float(np.max(np.abs(np.diff(pre_path))))
        a = np.zeros(len(names)); a[iq] = 1 / len(iq)
        theta = float(a @ cf.values); se_t = float(np.sqrt(a @ V @ a))
        sd = pre_sd(d, y); bounds = {}
        for M in [0, 0.5, 1.0, 1.5]:
            bias = M * B * np.mean([j + 1 for j in range(len(iq))])
            lo, hi = theta - bias - 1.96 * se_t, theta + bias + 1.96 * se_t
            bounds[str(M)] = dict(lo=lo, hi=hi, lo_sd=lo / sd, hi_sd=hi / sd)
        res[y] = dict(coefs=coefs, wald_chi2=W, wald_p_chi2=float(stats.chi2.sf(W, len(pre))),
                      wald_p_F=float(stats.f.sf(W / len(pre), len(pre), G - 1)), B=B, theta=theta, se_theta=se_t,
                      rm_bounds=bounds, n=int(m._N))
        print(y, 'wald p chi2', round(res[y]['wald_p_chi2'], 3), 'F', round(res[y]['wald_p_F'], 3), 'B', round(B, 3),
              'theta', round(theta, 3), {M: (round(v['lo_sd'], 2), round(v['hi_sd'], 2)) for M, v in bounds.items()}, flush=True)
    save('event', res)
    # TOST 等价检验（最小关心效应 0.2 SD）与 Holm 校正
    tost = {}
    for y in CORE:
        r = est(d, y); sd = pre_sd(d, y); delta = 0.2 * sd; df_ = G - 1
        p_lo = float(stats.t.sf((r['b'] + delta) / r['se'], df_)); p_hi = float(stats.t.cdf((r['b'] - delta) / r['se'], df_))
        tc = stats.t.ppf(0.95, df_)
        eq_bound = max(abs(r['b'] - tc * r['se']), abs(r['b'] + tc * r['se'])) / sd
        tost[y] = dict(b=r['b'], se=r['se'], sd=sd, p_tost_02=max(p_lo, p_hi), eq_bound_sd=float(eq_bound))
        print('TOST', y, round(max(p_lo, p_hi), 3), 'smallest equivalence bound (SD)', round(eq_bound, 2), flush=True)
    save('tost', tost)
    # 主要结果（三项核心，按 wild bootstrap p）与次要结果（按聚类 p）分别做 Holm 校正；p 值取自正文表格
    save('holm', dict(primary=holm({'tone_yao': 0.24, 'r_pess': 0.63, 'r_offi': 0.25}),
                      secondary=holm({'neg': 0.30, 'pos': 0.17, 'unc': 0.71, 'lntok': 0.18})))
    print('holm', json.load(open(OUT, encoding='utf-8'))['holm'])


# ------------------------------------------------------------------ composition, robustness rows, genre split
def cmd_comp():
    all_ = load_all(); d = main(all_); res = {}
    print('shares by group/period'); print(d.groupby(['treat', 'post'])[['report', 'interview', 'stock']].mean().round(3))
    comp = {}
    for y in ['report', 'interview', 'stock', 'lntok']:
        r = est(d, y); r['pre_mean_treat'] = float(d.loc[(d.treat == 1) & (d.post == 0), y].mean())
        r['means'] = {f'{t}{q}': float(v) for (t, q), v in d.groupby(['treat', 'post'])[y].mean().items()}
        comp[y] = r; print('comp', y, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items() if k != 'means'}, flush=True)
    save('composition', comp)
    rows = {}
    def row(lab, z, extra='', w=None):
        rows[lab] = {y: est(z, y, extra=extra, w=w) for y in CORE}
        print(lab, {y: (round(v['b'], 3), round(v['se'], 3), v['n']) for y, v in rows[lab].items()}, flush=True)
    row('genre_controls', d, extra=' + report + interview')
    row('drop_h2_2024', d[d['k'] != -1])
    row('donut', d[~((d['date'] >= '2024-12-03') & (d['date'] < '2025-04-01'))])
    row('no_stock_titles', d[d['stock'] == 0])
    z = d.copy(); z['w'] = 1.0 / z.groupby(['name', 'post'])['name'].transform('size'); row('equal_weights', z, w='w')
    # 仅限大模型判定为聚焦中国的文章（LLM 样本，2023 年 6 月起）
    sc = s5.load_scores('llm_scores.jsonl'); smp = pd.read_pickle(s5.SAMPLE)[['aid', 'name', '标题']]
    cf = smp.merge(sc[['aid', 'china_focus']], on='aid')
    z = d.merge(cf[['name', '标题', 'china_focus']], on=['name', '标题'], how='inner')
    z = z[z['china_focus'] == 1]
    row('china_focus_only', z)
    save('robust_rows', rows)
    split = {}
    for lab, z in [('non_report', d[d['report'] == 0]), ('report_vs_controls', d[(d['report'] == 1) | (d['treat'] == 0)])]:
        split[lab] = {y: est(z, y) for y in CORE}
        split[lab]['n_treated_post'] = int(((z.treat == 1) & (z.post == 1)).sum())
        print('split', lab, {y: (round(v['b'], 3), round(v['se'], 3), round(v['p'], 3)) for y, v in split[lab].items() if y in CORE},
              'treated post', split[lab]['n_treated_post'], flush=True)
    save('genre_split', split)


# ------------------------------------------------------------------ randomization inference, placebo distribution, leave-one-out
def fast_demean(X, codes, tol=1e-9, maxit=2000):
    """用 bincount 的交替投影去除经济学家和年月固定效应（与 step5.demean 等价，更快）。"""
    X = np.array(X, dtype=float, copy=True); X = X.reshape(len(X), -1)
    cnt = [np.bincount(c) for c in codes]
    for _ in range(maxit):
        old = X.copy()
        for c, n in zip(codes, cnt):
            for j in range(X.shape[1]):
                X[:, j] -= (np.bincount(c, weights=X[:, j]) / n)[c]
        if np.max(np.abs(X - old)) < tol: break
    return X


def fwl_beta(yd, xd, cd):
    """FWL：先把处理变量对 ln(length) 残差化，再求系数。"""
    g = (xd @ cd) / (cd @ cd); r = xd - g * cd
    return (r @ yd) / (r @ r)


def cmd_ri(nperm=1000):
    all_ = load_all(); d = main(all_); res = {}
    codes = [pd.factorize(d['name'])[0], pd.factorize(d['ym'])[0]]
    cols = CORE + ['lntok', 'tp']; Zm = fast_demean(d[cols].values, codes); Z = pd.DataFrame(Zm, columns=cols)
    actual = {y: fwl_beta(Z[y].values, Z['tp'].values, Z['lntok'].values) for y in CORE}
    names = np.array(sorted(d['name'].unique())); ntr = d.groupby('name')['treat'].first().sum()
    rng = np.random.default_rng(SEED); perm = {y: [] for y in CORE}
    for _ in range(nperm):
        tr = set(rng.choice(names, size=ntr, replace=False))
        xd = fast_demean((d['name'].isin(tr) & (d['post'] == 1)).astype(float).values, codes)[:, 0]
        for y in CORE:
            perm[y].append(fwl_beta(Z[y].values, xd, Z['lntok'].values))
    for y in CORE:
        pb = np.array(perm[y]); res[y] = dict(actual=float(actual[y]), p=float(np.mean(np.abs(pb) >= abs(actual[y]))))
    print('RI', {y: round(v['p'], 3) for y, v in res.items()}, 'actual', {y: round(v, 4) for y, v in actual.items()}, flush=True)
    save('ri_1000', res)
    # 逐月安慰剂：通知前样本（2019 年 1 月至 2024 年 9 月），假日期取 2020 年 1 月至 2023 年 12 月每月 1 日
    pz = all_[(all_['date'] < '2024-10-01')].reset_index(drop=True)
    plac = {y: [] for y in CORE}; dates = pd.date_range('2020-01-01', '2023-12-01', freq='MS')
    for fd in dates:
        z = pz.copy(); z['post'] = (z['date'] >= fd).astype(int); z['tp'] = z['treat'] * z['post']
        for y in CORE:
            plac[y].append(est(z, y)['b'])
    base = {y: est(d, y)['b'] for y in CORE}
    pres = {y: dict(n_dates=len(dates), share_abs_ge_actual=float(np.mean(np.abs(plac[y]) >= abs(base[y]))),
                    p05=float(np.percentile(plac[y], 5)), p95=float(np.percentile(plac[y], 95)), actual=base[y]) for y in CORE}
    print('placebo', {y: (round(v['share_abs_ge_actual'], 2), round(v['p05'], 3), round(v['p95'], 3)) for y, v in pres.items()},
          'N', len(pz), 'economists', pz['name'].nunique(), flush=True)
    save('placebo_monthly', dict(results=pres, n=int(len(pz)), k=int(pz['name'].nunique())))
    # 逐个剔除经济学家
    loo = {y: [] for y in CORE}
    for nm in names:
        z = d[d['name'] != nm]
        for y in CORE:
            loo[y].append(est(z, y)['b'])
    lres = {y: dict(min=float(np.min(v)), max=float(np.max(v)), who_min=str(names[int(np.argmin(v))]),
                    who_max=str(names[int(np.argmax(v))])) for y, v in loo.items()}
    print('leave-one-out', lres, flush=True)
    save('leave_one_out', lres)


# ------------------------------------------------------------------ dictionary term-level checks
def cmd_terms():
    import yaml, jieba, collections
    jieba.setLogLevel(60)
    D = os.path.join(list(importlib.util.find_spec('cntext').submodule_search_locations)[0], 'io', 'data') + os.sep
    def ld(f): return yaml.safe_load(open(D + f, encoding='utf-8'))['Dictionary']
    yao = ld('zh_common_FinacialFormalUnformal.yaml'); lm = ld('zh_common_LoughranMcDonald.yaml')
    hn = ld('zh_common_HowNet.yaml'); epu = ld('zh_common_EPU.yaml')
    src = open('step1_measures.py', encoding='utf-8').read()
    PESS = eval(re.search(r"PESS = (\[.*?\])", src, re.S).group(1)); OFFI = eval(re.search(r"OFFI = (\[.*?\])", src, re.S).group(1))
    sets = [set(yao['正式-肯定情绪']), set(yao['正式-否定情绪']), set(lm['positive']), set(lm['negative']),
            set(hn['pos']), set(hn['neg']), set(epu['不确定']), set(PESS), set(OFFI)]
    for s in sets:          # 与 step1 相同的加词顺序
        for w in s:
            if isinstance(w, str) and len(w) >= 2: jieba.add_word(w)
    for w in PESS + OFFI: jieba.add_word(w, freq=200000)
    d = main(); tok_re = re.compile(r'[\u4e00-\u9fff]'); terms = PESS + OFFI; rows = []
    for t in d['text'].tolist():
        c = collections.Counter(w for w in jieba.lcut(t, HMM=False) if tok_re.search(w))
        rows.append([c.get(w, 0) for w in terms])
    tc = pd.DataFrame(rows, columns=terms)
    ok_p = int((tc[PESS].sum(axis=1).values == d['pess'].values).mean() * len(d))
    ok_o = int((tc[OFFI].sum(axis=1).values == d['offi'].values).mean() * len(d))
    print('term counts reproduce step1 for', ok_p, 'and', ok_o, 'of', len(d), 'articles', flush=True)
    tc.to_pickle('term_counts.pkl')
    res = {'match': [ok_p, ok_o, len(d)]}
    for lab, lst, tot in [('pess', PESS, 'pess'), ('offi', OFFI, 'offi')]:
        bs = {}
        for w in lst:
            z = d.copy(); z['y'] = 1000 * (z[tot] - tc[w].values) / z['ntok']
            bs[w] = est(z, 'y')['b']
        base = est(d, f'r_{lab}')['b']
        res[lab] = dict(base=base, min=min(bs.values()), max=max(bs.values()),
                        who_min=min(bs, key=bs.get), who_max=max(bs, key=bs.get), share=float((tc[lst].sum(axis=1) > 0).mean()))
        print(lab, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in res[lab].items()}, flush=True)
    LEAD = ['习近平', '总书记', '党中央']; SLOG = [w for w in OFFI if w not in LEAD]
    z = d.copy(); z['r_lead'] = 1000 * tc[LEAD].sum(axis=1).values / z['ntok']; z['r_slog'] = 1000 * tc[SLOG].sum(axis=1).values / z['ntok']
    for y in ['r_lead', 'r_slog']:
        r = est(z, y); r['pre_mean_treat'] = float(z.loc[(z.treat == 1) & (z.post == 0), y].mean()); r['sd'] = pre_sd(z, y)
        res[y] = r; print(y, {k: round(v, 3) if isinstance(v, float) else v for k, v in r.items()}, flush=True)
    save('terms', res)


# ------------------------------------------------------------------ wild cluster bootstrap for the new headline results
def cmd_wcb(reps=1999):
    d = main(); res = {}
    tc = pd.read_pickle('term_counts.pkl')           # 由 terms 生成
    d['r_lead'] = 1000 * tc[['习近平', '总书记', '党中央']].sum(axis=1).values / d['ntok']
    jobs = [('lead_refs', d, 'r_lead'), ('comp_report', d, 'report'), ('comp_interview', d, 'interview'), ('comp_stock', d, 'stock'),
            ('nonreport_offi', d[d['report'] == 0], 'r_offi'), ('nonreport_tone', d[d['report'] == 0], 'tone_yao'),
            ('nonreport_pess', d[d['report'] == 0], 'r_pess')]
    for lab, z, y in jobs:
        z = z[z[y].notna()].reset_index(drop=True)
        res[lab] = s5.wcr(z, y, reps=reps); print(lab, round(res[lab], 3), flush=True)
    save('wcb', res)


if __name__ == '__main__':
    {'prep': lambda: print(len(load_all())), 'event': cmd_event, 'comp': cmd_comp, 'ri': cmd_ri,
     'terms': cmd_terms, 'wcb': cmd_wcb}[sys.argv[1]]()
