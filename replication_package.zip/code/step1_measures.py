# -*- coding: utf-8 -*-
"""Step 1: clean the CCEF corpus, code affiliations, build text measures."""
import re, yaml, pandas as pd, numpy as np, jieba
jieba.setLogLevel(60)
import os, importlib.util
# 词典文件随 cntext 包安装；只读取其中的 yaml，不导入 cntext 本身
D = os.path.join(list(importlib.util.find_spec('cntext').submodule_search_locations)[0], 'io', 'data') + os.sep
EXCEL = '中国首席经济学家-专家文章汇总2026.xlsx'  # 改成你的 Excel 路径

df = pd.read_excel(EXCEL, dtype=str)
df['name'] = df['姓名'].fillna('').str.replace(r'\s+', '', regex=True)
df['text'] = df['文章详情'].fillna('').astype(str)
df['date'] = pd.to_datetime(df['日期'], errors='coerce')
df['backfill'] = df['日期'].fillna('').str.endswith('23:55:00').astype(int)
n0 = len(df)
df = df[~df['name'].isin(['CCEF', '首席论坛'])]
n1 = len(df)
df = df[df['text'].str.len() >= 300]
n2 = len(df)
df = df.drop_duplicates(subset=['name', '标题'])
n3 = len(df)
print('raw', n0, 'drop institutional', n0 - n1, 'drop short', n1 - n2, 'drop dup', n2 - n3, 'final', n3)

# ---------------- affiliation coding (as of the 18 Dec 2024 SAC notice) ----------------
SEC = ['赵伟','李超','钟正生','管涛','杨德龙','郭磊','李奇霖','李湛','熊园','伍戈','徐高','彭文生','高善文',
       '王涵','荀玉根','罗志恒','黄文涛','杨成长','陈洪斌','沈明高','董忠云','陈李','芦哲','高瑞东','燕翔',
       '何海峰','牛播坤','章俊','张一','郑后成','陈雳','李宗光','袁宜','段辰菊','赵雪芹','汪毅','姚余栋','陈达飞']
BANK = ['鲁政委','唐建伟','鄂永健','殷剑峰','黄志凌','刘晓曙']
HKCN = ['程实','曹远征','崔历','李迅雷','周浩']
FOREIGN = ['汪涛','朱海斌','陆挺','刘利刚','邢自强','丁爽','胡伟俊','乔虹','杨宇霆','陈兴动','王志浩',
           '闪辉','熊奕','常健','余向荣','夏乐','许思涛']
ACAD = ['张明','邵宇','盛松成','连平','赵建','马骏','夏斌','刘锋','颜色','林采宜','刘煜辉','潘向东','钱学宁',
        '刘涛','廖群']
OTHER = ['沈建光','王军','俞平康','夏春','梁文涛','孙明春','何帆','花长春','张岸元','张智威','洪灝','屈宏斌',
         '陶冬','刘建辉','张达斌','朱斌','朱菁','华俊','梁红','赵扬']
AMBIG = ['刘郁','程强','薛鹤翔','蔡浩','诸建芳','丁安华','汤云飞']
aff = {}
for lst, lab in [(SEC,'SEC'),(BANK,'BANK'),(HKCN,'HKCN'),(FOREIGN,'FOREIGN'),(ACAD,'ACAD'),(OTHER,'OTHER'),(AMBIG,'AMBIG')]:
    for n in lst: aff[n] = lab
df['aff'] = df['name'].map(aff).fillna('UNCODED')
print(df['aff'].value_counts())
print('uncoded:', df.loc[df.aff=='UNCODED','name'].unique())

# ---------------- dictionaries ----------------
def load(f): return yaml.safe_load(open(D+f, encoding='utf-8'))['Dictionary']
yao = load('zh_common_FinacialFormalUnformal.yaml')
lm = load('zh_common_LoughranMcDonald.yaml')
hn = load('zh_common_HowNet.yaml')
epu = load('zh_common_EPU.yaml')
DICTS = {
 'yao_pos': set(yao['正式-肯定情绪']), 'yao_neg': set(yao['正式-否定情绪']),
 'lm_pos': set(lm['positive']), 'lm_neg': set(lm['negative']),
 'hn_pos': set(hn['pos']), 'hn_neg': set(hn['neg']),
 'unc': set(epu['不确定']),
}
PESS = ['通缩','通货紧缩','债务通缩','资产负债表衰退','日本化','失去的十年','失去的三十年','流动性陷阱','衰退',
        '萧条','滞胀','失业','失业率','青年失业率','需求不足','内需不足','有效需求不足','信心不足','预期转弱',
        '预期偏弱','硬着陆','债务危机','爆雷','暴雷','崩盘','违约潮','螺旋式下跌','负反馈']
OFFI = ['高质量发展','新质生产力','中国式现代化','新发展格局','新发展理念','稳中求进','稳中向好','回升向好',
        '长期向好','光明论','以进促稳','先立后破','统筹发展和安全','共同富裕','习近平','总书记','党中央',
        '韧性强','潜力大','活力足']
DICTS['pess'] = set(PESS); DICTS['offi'] = set(OFFI)
for s in DICTS.values():
    for w in s:
        if isinstance(w, str) and len(w) >= 2: jieba.add_word(w)
# make sure the two unit-conflict pairs are tokenised as whole words
for w in PESS + OFFI: jieba.add_word(w, freq=200000)

tok_re = re.compile(r'[\u4e00-\u9fff]')
rows = []
for i, t in enumerate(df['text'].tolist()):
    toks = [w for w in jieba.lcut(t, HMM=False) if tok_re.search(w)]
    n = len(toks)
    c = {k: sum(1 for w in toks if w in s) for k, s in DICTS.items()}
    c['ntok'] = n
    rows.append(c)
    if i % 2000 == 0: print(i, flush=True)
m = pd.DataFrame(rows, index=df.index)
df = pd.concat([df, m], axis=1)
for p in ['yao', 'lm', 'hn']:
    df[f'tone_{p}'] = (df[f'{p}_pos'] - df[f'{p}_neg']) / (df[f'{p}_pos'] + df[f'{p}_neg']).replace(0, np.nan)
for k in ['yao_pos','yao_neg','unc','pess','offi']:
    df[f'r_{k}'] = 1000 * df[k] / df['ntok']
df['lntok'] = np.log(df['ntok'])
keep = ['name','aff','date','backfill','标题','ntok','lntok'] + list(DICTS.keys()) + \
       ['tone_yao','tone_lm','tone_hn','r_yao_pos','r_yao_neg','r_unc','r_pess','r_offi']
df[keep].to_pickle('measures.pkl')
print(df[keep].describe().T.to_string())
