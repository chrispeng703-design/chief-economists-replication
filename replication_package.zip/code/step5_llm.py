# -*- coding: utf-8 -*-
"""
大模型立场指标：抽样 -> 打分 -> 人工验证 -> DID

Windows 命令行用法（在脚本所在目录运行，需先跑完 step1 得到 measures.pkl）：
  python step5_llm.py sample                                   # 生成待打分样本 llm_sample.pkl
  python step5_llm.py score --provider mock                    # 不调用 API 的试运行，检查流程
  python step5_llm.py score --provider deepseek --limit 20     # 先小批量试 20 篇
  python step5_llm.py score --provider deepseek --workers 4    # 全量打分，可随时中断、重跑续传
  python step5_llm.py export-human                             # 导出人工验证材料（试编码 20 篇 + 正式 200 篇，编码员 A/B 各一份）
  python step5_llm.py validate                                 # 编码员间一致性、分歧裁决表、模型对人工的一致性与误差检验
  python step5_llm.py validate                                 # 人工标注填好后计算一致性
  python step5_llm.py did                                      # 合并得分，跑 DID、事件研究、自助法
  python step5_llm.py score --provider qwen --model qwen3-235b-a22b-instruct-2507 --subsample 500 --out llm_scores_qwen3-235b.jsonl
  python step5_llm.py agree --b llm_scores_qwen3-235b.jsonl    # 两个模型的一致性
  python step5_llm.py robust                                   # 6.5 节的补充检验（先跑 did）

API 密钥放在环境变量里（命令行里 set DEEPSEEK_API_KEY=sk-xxx）：
  DEEPSEEK_API_KEY / DASHSCOPE_API_KEY / ANTHROPIC_API_KEY
模型名称会更新，运行前请到各家文档确认，用 --model 覆盖默认值。
"""
import os, re, sys, json, time, hashlib, argparse, threading, random
from concurrent.futures import ThreadPoolExecutor, as_completed
import numpy as np, pandas as pd

EXCEL = '中国首席经济学家-专家文章汇总2026.xlsx'   # 原始数据
MEASURES = 'measures.pkl'                          # step1 输出
SAMPLE = 'llm_sample.pkl'
SCORES = 'llm_scores.jsonl'
HUMAN = 'human_coding.xlsx'
HUMAN_KEY = 'human_key.csv'
HUMAN_COLS = ['stance', 'china_focus', 'risk_emphasis', 'hedging', 'policy', '通缩', '就业', '房地产下行', '地方债务', '数据质量']
EVENT = pd.Timestamp('2024-12-18')
WINDOW_START = '2023-06-18'      # 事件时间 k >= -3，即通知前 18 个月
HEAD, TAIL = 4500, 1500          # 长文截取首 4500 字 + 尾 1500 字，保留结论段

PROVIDERS = {
    'deepseek': dict(url='https://api.deepseek.com/chat/completions', key='DEEPSEEK_API_KEY',
                     style='openai', model='deepseek-chat'),
    'qwen': dict(url='https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions',
                 key='DASHSCOPE_API_KEY', style='openai', model='qwen-plus-2025-12-01'),
    'claude': dict(url='https://api.anthropic.com/v1/messages', key='ANTHROPIC_API_KEY',
                   style='anthropic', model='claude-sonnet-5'),
    'mock': dict(url=None, key=None, style='mock', model='mock'),
}

SYSTEM = ('你是经济学研究助理，负责对中国经济评论文章做内容编码。'
          '只根据文章文本判断，不要推测作者身份或所属机构。只输出一个 JSON 对象，不要输出其他内容。')

PROMPT = """请阅读下面这篇经济评论，按以下定义编码。

1. stance：文章对中国经济前景（未来 6 到 12 个月的增长、就业、物价、资产价格）的整体判断。
   -2 = 明显悲观；-1 = 偏悲观；0 = 中性或多空并陈；1 = 偏乐观；2 = 明显乐观。
   如果文章主要讨论海外经济或具体技术问题、与中国经济前景无关，填 null。
2. china_focus：文章是否主要讨论中国经济，1 或 0。
3. risk_emphasis：对中国经济下行风险的强调程度。0 = 几乎不提；1 = 提及但非重点；2 = 作为核心论点。
4. hedging：表述的保留和回避程度。0 = 判断明确；1 = 有一定保留；2 = 大量模糊、回避性表述。
5. policy_endorsement：对现行经济政策的态度。-1 = 批评或质疑；0 = 中性或未涉及；1 = 肯定或呼应官方表述。
   明确指出现行政策力度不足、效果有限或方向有误，记 -1；仅呼吁政策加码、未评价现行政策，不算肯定。
6. topics：是否实质讨论了下列话题，各填 1 或 0：
   deflation（通缩或物价持续低迷）、employment（就业或失业）、property（房地产下行）、
   local_debt（地方政府债务）、data_quality（统计数据质量）。
7. reason：用一句话（不超过 40 字）说明 stance 的依据。

文末“风险提示”、免责声明等格式化段落不计入以上任何一项判断。

只输出如下格式的 JSON：
{{"stance": 0, "china_focus": 1, "risk_emphasis": 0, "hedging": 0, "policy_endorsement": 0,
 "topics": {{"deflation": 0, "employment": 0, "property": 0, "local_debt": 0, "data_quality": 0}},
 "reason": ""}}

文章：
<<<
{text}
>>>"""


# ------------------------------------------------------------------ data
def load_corpus():
    """复现 step1 的清洗，拿到正文，再与 measures.pkl 按 (姓名, 标题) 一对一合并。"""
    raw = pd.read_excel(EXCEL, dtype=str)
    raw['name'] = raw['姓名'].fillna('').str.replace(r'\s+', '', regex=True)
    raw['text'] = raw['文章详情'].fillna('').astype(str)
    raw = raw[~raw['name'].isin(['CCEF', '首席论坛'])]
    raw = raw[raw['text'].str.len() >= 300].drop_duplicates(subset=['name', '标题'])
    m = pd.read_pickle(MEASURES)
    df = m.merge(raw[['name', '标题', 'text']], on=['name', '标题'], how='left', validate='1:1')
    return df


def prep_text(text, name):
    t = re.sub(r'\s+', ' ', str(text)).replace(name, '作者')   # 去掉作者姓名，避免模型按人判断
    return t if len(t) <= HEAD + TAIL else t[:HEAD] + ' …… ' + t[-TAIL:]


def cmd_sample(a):
    df = load_corpus()
    df = df[(df['aff'] != 'AMBIG') & (df['ntok'] >= 200) & (df['date'] >= a.start)].copy()
    df = df.sort_values(['date', 'name', '标题']).reset_index(drop=True)
    df['aid'] = [hashlib.md5(f'{n}|{t}'.encode('utf-8')).hexdigest()[:12] for n, t in zip(df['name'], df['标题'])]
    df['prompt_text'] = [prep_text(t, n) for t, n in zip(df['text'], df['name'])]
    df['treat'] = (df['aff'] == 'SEC').astype(int)
    df['post'] = (df['date'] >= EVENT).astype(int)
    df.drop(columns=['text']).to_pickle(SAMPLE)
    chars = df['prompt_text'].str.len().sum()
    print(f'样本 {len(df)} 篇，{df["name"].nunique()} 位经济学家；起始日期 {a.start}')
    print(df.groupby(['treat', 'post']).size().rename('articles').to_string())
    print(f'送入模型的正文约 {chars/1e6:.1f} 百万字，按每字约 0.6-1 个 token 估算输入量，请对照所选模型的计价核算成本')


# ------------------------------------------------------------------ scoring
def call_model(p, model, text, timeout=120):
    user = PROMPT.format(text=text)
    if p['style'] == 'mock':      # 试运行：确定性的伪得分，只用于检查流程
        h = int(hashlib.md5(text.encode('utf-8')).hexdigest(), 16)
        return json.dumps({'stance': h % 5 - 2, 'china_focus': 1, 'risk_emphasis': h % 3, 'hedging': (h >> 3) % 3,
                           'policy_endorsement': (h >> 5) % 3 - 1,
                           'topics': {k: (h >> i) % 2 for i, k in enumerate(
                               ['deflation', 'employment', 'property', 'local_debt', 'data_quality'])},
                           'reason': 'mock'}, ensure_ascii=False), 'mock'
    import requests
    key = os.environ.get(p['key'])
    if not key:
        sys.exit(f'没有找到环境变量 {p["key"]}')
    if p['style'] == 'openai':
        r = requests.post(p['url'], timeout=timeout, headers={'Authorization': f'Bearer {key}'},
                          json={'model': model, 'temperature': 0, 'max_tokens': 400,
                                'messages': [{'role': 'system', 'content': SYSTEM}, {'role': 'user', 'content': user}]})
        r.raise_for_status()
        j = r.json()
        return j['choices'][0]['message']['content'], j.get('model', model)
    r = requests.post(p['url'], timeout=timeout,
                      headers={'x-api-key': key, 'anthropic-version': '2023-06-01'},
                      json={'model': model, 'max_tokens': 400, 'temperature': 0, 'system': SYSTEM,
                            'messages': [{'role': 'user', 'content': user}]})
    r.raise_for_status()
    j = r.json()
    return ''.join(b.get('text', '') for b in j['content']), j.get('model', model)


def parse(raw):
    s = re.sub(r'```(json)?', '', raw)
    m = re.search(r'\{.*\}', s, re.S)
    if not m:
        raise ValueError('no json')
    d = json.loads(m.group(0))
    st = d.get('stance')
    if st is not None and st not in (-2, -1, 0, 1, 2):
        raise ValueError(f'bad stance {st}')
    return d


def cmd_score(a):
    p = PROVIDERS[a.provider]; model = a.model or p['model']
    s = pd.read_pickle(SAMPLE)
    out = a.out or (SCORES if a.provider != 'mock' else 'llm_scores_mock.jsonl')
    done = set()
    if os.path.exists(out):
        with open(out, encoding='utf-8') as f:
            done = {json.loads(l)['aid'] for l in f if l.strip()}
    if a.subsample:   # 按处理组×前后期分层随机抽样，用于第二个模型重打
        per = a.subsample // 4
        s = pd.concat([g.sample(min(per, len(g)), random_state=a.seed) for _, g in s.groupby(['treat', 'post'])])
    todo = s[~s['aid'].isin(done)]
    if a.limit: todo = todo.head(a.limit)
    print(f'模型 {a.provider}/{model}：已完成 {len(done)}，本次待打分 {len(todo)}')
    lock = threading.Lock()

    def work(row):
        for attempt in range(6):
            try:
                raw, api_model = call_model(p, model, row.prompt_text)
                d = parse(raw)
                return dict(aid=row.aid, model=model, api_model=api_model, ts=time.strftime('%Y-%m-%d %H:%M:%S'), raw=raw, **{
                    'stance': d.get('stance'), 'china_focus': d.get('china_focus'),
                    'risk_emphasis': d.get('risk_emphasis'), 'hedging': d.get('hedging'),
                    'policy_endorsement': d.get('policy_endorsement'), 'topics': d.get('topics', {}),
                    'reason': d.get('reason', '')})
            except Exception as e:
                wait = min(60, 2 ** attempt + random.random())
                if attempt == 5:
                    return dict(aid=row.aid, model=model, error=str(e)[:200])
                time.sleep(wait)

    n = 0
    with ThreadPoolExecutor(max_workers=a.workers) as ex, open(out, 'a', encoding='utf-8') as f:
        for fut in as_completed([ex.submit(work, r) for r in todo.itertuples()]):
            rec = fut.result()
            if 'error' in rec:
                print('失败', rec['aid'], rec['error']); continue   # 失败的不写入，下次重跑自动补
            with lock:
                f.write(json.dumps(rec, ensure_ascii=False) + '\n'); f.flush()
            n += 1
            if n % 50 == 0: print(f'已完成 {n}/{len(todo)}', flush=True)
            if a.sleep: time.sleep(a.sleep)
    print(f'本次写入 {n} 条 -> {out}')


def load_scores(path):
    rows = [json.loads(l) for l in open(path, encoding='utf-8') if l.strip()]
    sc = pd.DataFrame(rows).drop_duplicates('aid', keep='last')
    t = pd.json_normalize(sc['topics'].apply(lambda x: x if isinstance(x, dict) else {})).add_prefix('topic_')
    sc = pd.concat([sc.drop(columns=['topics']).reset_index(drop=True), t], axis=1)
    for c in ['stance', 'china_focus', 'risk_emphasis', 'hedging', 'policy_endorsement'] + list(t.columns):
        sc[c] = pd.to_numeric(sc[c], errors='coerce')
    return sc


# ------------------------------------------------------------------ human validation
CODEBOOK = [
 ('一、基本原则', [
  '1. 只根据正文判断。不查作者、不搜索原文，不使用任何 AI 工具（ChatGPT、豆包、Kimi、通义等）辅助判断。',
  '2. 两位编码员各自独立完成，全部编完之前不讨论具体文章，也不交换编码表。',
  '3. 正文中的“作者”是替换后的作者姓名。不要试图推断作者是谁、在哪家机构。',
  '4. 文末“风险提示”、免责声明等格式化段落不计入任何一项判断。',
  '5. 按序号顺序编码，每次连续编码不超过 25 篇。拿不准时选最接近的一档，并在“备注”栏写一句理由。',
  '6. 先完成 20 篇试编码，与项目负责人讨论分歧、统一理解后，再开始 200 篇正式编码。正式编码开始后不再修改手册。']),
 ('二、变量定义', [
  'stance（-2 到 2，或 NA）：文章对中国经济前景（未来 6 到 12 个月的增长、就业、物价、资产价格）的整体判断。-2 明显悲观；-1 偏悲观；0 中性或多空并陈；1 偏乐观；2 明显乐观。文章主要讨论海外经济或具体技术问题、与中国经济前景无关时，填 NA。',
  'china_focus（0/1）：文章是否主要讨论中国经济。',
  'risk_emphasis（0 到 2）：对中国经济下行风险的强调程度。0 几乎不提；1 提及但非重点；2 作为核心论点。',
  'hedging（0 到 2）：表述的保留和回避程度。0 判断明确；1 有一定保留；2 大量模糊、回避性表述。',
  'policy（-1 到 1）：对现行经济政策的态度。-1 批评或质疑；0 中性或未涉及；1 肯定或呼应官方表述。',
  '五个话题（各 0/1）：是否实质讨论了通缩（或物价持续低迷）、就业（或失业）、房地产下行、地方政府债务、统计数据质量。']),
 ('三、判断细则', [
  'stance 看全文对中国整体经济前景的判断，不看对单个行业、个股或海外市场的判断。',
  'china_focus 填 0 时，stance 一般填 NA；china_focus 填 1 但文章只讲政策机制、完全不涉及前景判断时，stance 填 NA 并在备注说明。',
  '“短期承压、长期向好”这类表述看全文重心：大篇幅论述下行压力记 -1，以向好论证为主记 1，两者相当记 0。',
  'hedging：给出明确方向判断记 0；判断中带“或”“可能”“有望”等限定但仍有方向记 1；回避判断、正反并列不下结论记 2。',
  'policy：明确指出现行政策力度不足、效果有限或方向有误记 -1；仅呼吁政策加码、没有评价现行政策记 0；以肯定现行政策、呼应官方表述为主记 1。',
  '话题的“实质讨论”指至少有几句专门分析，只顺带出现一个词不算。']),
]


def cmd_export_human(a):
    """导出人工验证材料：20 篇试编码 + 200 篇正式编码（每个处理组×前后期各 50 篇），两位编码员各一份编码表。"""
    from openpyxl import load_workbook
    from openpyxl.styles import Font, Alignment, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation
    s = pd.read_pickle(SAMPLE)
    coded = set(load_scores(SCORES)['aid']) if os.path.exists(SCORES) else set(s['aid'])
    s = s[s['aid'].isin(coded)]                                   # 只抽模型已编码的文章
    per = a.n // 4
    main = pd.concat([g.sample(min(per, len(g)), random_state=2026) for _, g in s.groupby(['treat', 'post'])])
    rest = s[~s['aid'].isin(main['aid'])]
    train = pd.concat([g.sample(5, random_state=2027) for _, g in rest.groupby(['treat', 'post'])])
    main = main.sample(frac=1, random_state=7).reset_index(drop=True)      # 打乱顺序，编码员看不到组别
    train = train.sample(frac=1, random_state=8).reset_index(drop=True)
    main['hid'] = [f'H{i:03d}' for i in range(1, len(main) + 1)]
    train['hid'] = [f'T{i:02d}' for i in range(1, len(train) + 1)]
    key = pd.concat([train, main])[['hid', 'aid', 'treat', 'post']]
    key.to_csv(HUMAN_KEY, index=False, encoding='utf-8-sig')               # 对照表只由项目负责人保存
    json.dump({'codebook': CODEBOOK,
               'train': [dict(hid=r.hid, text=r.prompt_text) for r in train.itertuples()],
               'main': [dict(hid=r.hid, text=r.prompt_text) for r in main.itertuples()]},
              open('human_articles.json', 'w', encoding='utf-8'), ensure_ascii=False)
    cols = HUMAN_COLS
    for coder in ['A', 'B']:
        f = f'human_coding_{coder}.xlsx'
        with pd.ExcelWriter(f, engine='openpyxl') as w:
            flat = []
            for h, lines in CODEBOOK:
                flat.append(h); flat.extend(lines); flat.append('')
            pd.DataFrame({'编码手册': flat}).to_excel(w, sheet_name='编码手册', index=False)
            for sheet, ids in [('试编码', train['hid']), ('正式编码', main['hid'])]:
                df = pd.DataFrame({'序号': ids}); [df.__setitem__(c, '') for c in cols]; df['备注'] = ''
                df.to_excel(w, sheet_name=sheet, index=False)
        wb = load_workbook(f)
        ws = wb['编码手册']; ws.column_dimensions['A'].width = 120
        for row in ws.iter_rows():
            for c in row:
                c.alignment = Alignment(wrap_text=True, vertical='top'); c.font = Font(name='Arial', size=11, bold=str(c.value or '').startswith(('一、', '二、', '三、')))
        opts = {'stance': '"-2,-1,0,1,2,NA"', 'china_focus': '"0,1"', 'risk_emphasis': '"0,1,2"', 'hedging': '"0,1,2"',
                'policy': '"-1,0,1"'}
        for sheet in ['试编码', '正式编码']:
            ws = wb[sheet]; n = ws.max_row
            ws.freeze_panes = 'B2'; ws.column_dimensions['A'].width = 8
            for j, c in enumerate(cols, start=2):
                col = ws.cell(row=1, column=j).column_letter
                ws.column_dimensions[col].width = 13
                dv = DataValidation(type='list', formula1=opts.get(c, '"0,1"'), allow_blank=True, showErrorMessage=True,
                                    errorTitle='无效输入', error='请从下拉列表中选择')
                ws.add_data_validation(dv); dv.add(f'{col}2:{col}{n}')
            ws.column_dimensions[ws.cell(row=1, column=len(cols) + 2).column_letter].width = 50
            for c in ws[1]:
                c.font = Font(name='Arial', bold=True); c.fill = PatternFill('solid', start_color='DDEBF7'); c.alignment = Alignment(wrap_text=True)
        wb.save(f)
    print(f'试编码 {len(train)} 篇，正式编码 {len(main)} 篇（每组 {per} 篇）；对照表 {HUMAN_KEY}')


def qwk(x, y, lo, hi):
    """二次加权 Cohen's kappa。"""
    k = hi - lo + 1; O = np.zeros((k, k))
    for i, j in zip(x, y): O[int(i) - lo, int(j) - lo] += 1
    W = np.array([[(i - j) ** 2 for j in range(k)] for i in range(k)]) / (k - 1) ** 2
    E = np.outer(O.sum(1), O.sum(0)) / O.sum()
    return 1 - (W * O).sum() / (W * E).sum()


TOPIC_MAP = {'通缩': 'topic_deflation', '就业': 'topic_employment', '房地产下行': 'topic_property',
             '地方债务': 'topic_local_debt', '数据质量': 'topic_data_quality'}
MODEL_COL = dict({'stance': 'stance', 'china_focus': 'china_focus', 'risk_emphasis': 'risk_emphasis',
                  'hedging': 'hedging', 'policy': 'policy_endorsement'}, **TOPIC_MAP)
SCALE = {'stance': (-2, 2), 'risk_emphasis': (0, 2), 'hedging': (0, 2), 'policy': (-1, 1)}
ADJ = 'human_adjudication.xlsx'


def read_coder(f, sheet=None):
    if sheet is None:
        sheet = next(n for n in pd.ExcelFile(f).sheet_names if n.startswith('正式编码'))
    h = pd.read_excel(f, sheet_name=sheet, dtype=str, keep_default_na=False).rename(columns={'序号': 'hid'})   # 保留字面“NA”
    out = h[['hid']].copy()
    for c in HUMAN_COLS:
        v = h[c].fillna('').astype(str).str.strip()
        out[c] = pd.to_numeric(v.where(~v.str.upper().eq('NA')), errors='coerce')
        out[c + '_na'] = v.str.upper().eq('NA'); out[c + '_blank'] = v.eq('')
    return out


def agree_stats(x, y, c):
    z = pd.DataFrame({'x': x, 'y': y}).dropna()
    r = dict(n=int(len(z)), exact=float((z.x == z.y).mean()))
    if c in SCALE:
        lo, hi = SCALE[c]
        r.update(within1=float(((z.x - z.y).abs() <= 1).mean()), qwk=float(qwk(z.x, z.y, lo, hi)),
                 spearman=float(z.x.corr(z.y, method='spearman')))
    else:
        pe = z.x.mean() * z.y.mean() + (1 - z.x.mean()) * (1 - z.y.mean())
        r.update(kappa=float((r['exact'] - pe) / (1 - pe)) if pe < 1 else float('nan'))
    return r


def cmd_validate(a):
    """人工验证：编码员间一致性 → 分歧裁决表 → 模型与裁决后人工编码的一致性，及模型误差是否随处理×事后变化。"""
    import statsmodels.formula.api as smf
    A, B = read_coder('human_coding_A.xlsx'), read_coder('human_coding_B.xlsx')
    key = pd.read_csv(HUMAN_KEY, encoding='utf-8-sig')
    res = {'completeness': {}}
    for lab, X in [('A', A), ('B', B)]:
        res['completeness'][lab] = {c: int(X[c + '_blank'].sum()) for c in HUMAN_COLS}
    print('未填写的格子数：', res['completeness'])
    # 1. 编码员之间
    inter = {'stance_na_agree': float((A['stance_na'] == B['stance_na']).mean())}
    for c in HUMAN_COLS:
        inter[c] = agree_stats(A[c], B[c], c)
    res['inter_coder'] = inter
    # 2. 分歧裁决表：只列出两人不一致的格子，由第三人（项目负责人）填写最终值
    AB = A.merge(B, on='hid', suffixes=('_A', '_B'))
    def val(r, c, s_):
        return 'NA' if r[f'{c}_na_{s_}'] else ('' if pd.isna(r[f'{c}_{s_}']) else int(r[f'{c}_{s_}']))
    if not os.path.exists(ADJ):
        rows = [dict(序号=r['hid'], 变量=c, 编码员A=val(r, c, 'A'), 编码员B=val(r, c, 'B'), 最终值='', 理由='')
                for _, r in AB.iterrows() for c in HUMAN_COLS if val(r, c, 'A') != val(r, c, 'B')]
        pd.DataFrame(rows).to_excel(ADJ, index=False)
        print(f'已生成裁决表 {ADJ}，共 {len(rows)} 处分歧。填好“最终值”后再运行一次 validate。')
    adj = pd.read_excel(ADJ, dtype=str, keep_default_na=False)
    res['n_disagreements'] = int(len(adj)); res['n_adjudicated'] = int((adj['最终值'].str.strip() != '').sum())
    # 3. 共识编码：两人一致取一致值，不一致取裁决值；裁决未完成的格子暂缺
    cons = pd.DataFrame({'hid': AB['hid']})
    for c in HUMAN_COLS:
        agree = AB.apply(lambda r: val(r, c, 'A') == val(r, c, 'B'), axis=1)
        cons['h_' + c] = np.where(agree, AB[f'{c}_A'], np.nan); cons['h_' + c + '_na'] = np.where(agree, AB[f'{c}_na_A'], False)
    for r in adj.itertuples():
        v = str(r.最终值).strip()
        if v == '': continue
        i = cons.index[cons['hid'] == r.序号][0]
        cons.loc[i, 'h_' + r.变量 + '_na'] = v.upper() == 'NA'
        cons.loc[i, 'h_' + r.变量] = np.nan if v.upper() == 'NA' else float(v)
    # 4. 模型对共识编码
    sc = load_scores(a.scores); smp = pd.read_pickle(SAMPLE)[['aid', 'name']]
    d = cons.merge(key, on='hid').merge(sc, on='aid').merge(smp, on='aid')
    mvh = {'stance_na_agree': float((d['h_stance_na'].astype(bool) == d['stance'].isna()).mean())}
    for c in HUMAN_COLS:
        m = d[MODEL_COL[c]]; h = d['h_' + c]
        r = agree_stats(m, h, c)
        z = pd.DataFrame({'err': m - h, 'treat': d['treat'], 'post': d['post'], 'name': d['name']}).dropna()
        z['tp'] = z['treat'] * z['post']
        if len(z) >= 20:
            fit = smf.ols('err ~ treat + post + tp', data=z).fit(cov_type='cluster', cov_kwds={'groups': pd.factorize(z['name'])[0]})
            r.update(err_tp=float(fit.params['tp']), err_tp_se=float(fit.bse['tp']), err_tp_p=float(fit.pvalues['tp']))
        mvh[c] = r
    res['model_vs_consensus'] = mvh
    json.dump(res, open('llm_validation.json', 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
    print(json.dumps(res, indent=1, ensure_ascii=False))


# ------------------------------------------------------------------ DiD
def demean(df, cols, fes=('name', 'ym'), tol=1e-10, maxit=1000):
    X = df[cols].astype(float).copy()
    for _ in range(maxit):
        old = X.values.copy()
        for f in fes: X = X - X.groupby(df[f]).transform('mean')
        if np.max(np.abs(X.values - old)) < tol: break
    return X


def crv_t(y, X, cl, j):
    XtX = np.linalg.inv(X.T @ X); b = XtX @ X.T @ y; e = y - X @ b
    meat = np.zeros((X.shape[1], X.shape[1]))
    for g in np.unique(cl):
        idx = cl == g; sg = X[idx].T @ e[idx]; meat += np.outer(sg, sg)
    n, k = X.shape; G = len(np.unique(cl)); c = G / (G - 1) * (n - 1) / (n - k)
    return b[j] / np.sqrt((c * XtX @ meat @ XtX)[j, j])


def wcr(df, y, x='tp', ctrl=('lntok',), reps=1999, seed=11):
    Z = demean(df, [y, x] + list(ctrl)); Y = Z[y].values; X = Z[[x] + list(ctrl)].values; cl = df['name'].values
    t0 = crv_t(Y, X, cl, 0); Xr = Z[list(ctrl)].values
    fit = Xr @ np.linalg.lstsq(Xr, Y, rcond=None)[0]; res = Y - fit
    G, inv = np.unique(cl, return_inverse=True); rng = np.random.default_rng(seed)
    web = np.array([-np.sqrt(1.5), -1, -np.sqrt(.5), np.sqrt(.5), 1, np.sqrt(1.5)])
    ts = [crv_t(fit + rng.choice(web, len(G))[inv] * res, X, cl, 0) for _ in range(reps)]
    return float(np.mean(np.abs(ts) >= abs(t0)))


def cmd_did(a):
    import pyfixest as pf
    sc = load_scores(a.scores); s = pd.read_pickle(SAMPLE)
    if (sc['model'] == 'mock').any():
        print('!!! 注意：当前得分来自 mock 试运行，结果没有任何实际含义，不能写进论文 !!!')
    d = s.merge(sc, on='aid', how='inner')
    d['tp'] = d['treat'] * d['post']; d['ym'] = d['date'].dt.strftime('%Y-%m')
    d['k'] = np.floor((d['date'] - EVENT).dt.days / 182.5).astype(int).clip(lower=-3, upper=2)
    outs = ['stance', 'risk_emphasis', 'hedging', 'policy_endorsement'] + \
           [c for c in d.columns if c.startswith('topic_')]
    res = {'n_scored': int(len(d)), 'n_china': int((d['china_focus'] == 1).sum()), 'model': sorted(sc['model'].unique())}
    base = {}
    for y in outs:
        z = d[(d['china_focus'] == 1) & d[y].notna()].reset_index(drop=True) if y == 'stance' else d[d[y].notna()].reset_index(drop=True)
        m = pf.feols(f'{y} ~ tp + lntok | name + ym', data=z, vcov={'CRV1': 'name'}); t = m.tidy().loc['tp']
        sd = z.loc[z['post'] == 0, y].std()
        base[y] = dict(b=float(t['Estimate']), se=float(t['Std. Error']), p=float(t['Pr(>|t|)']), n=int(m._N),
                       k=int(z['name'].nunique()), pre_mean_treat=float(z.loc[(z.treat == 1) & (z.post == 0), y].mean()),
                       b_sd=float(t['Estimate'] / sd), ci_sd=[float((t['Estimate'] - 1.96 * t['Std. Error']) / sd),
                                                             float((t['Estimate'] + 1.96 * t['Std. Error']) / sd)])
        base[y]['wcb_p'] = wcr(z, y, reps=a.reps)
        print(y, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in base[y].items()}, flush=True)
    res['baseline'] = base
    # 同一样本上的词典语调，便于和大模型立场直接比较
    dict_res = {}
    for lab, z in [('all', d), ('china', d[(d['china_focus'] == 1) & d['stance'].notna()])]:
        z = z[z['tone_yao'].notna()].reset_index(drop=True)
        m = pf.feols('tone_yao ~ tp + lntok | name + ym', data=z, vcov={'CRV1': 'name'}); t = m.tidy().loc['tp']
        sd = z.loc[z['post'] == 0, 'tone_yao'].std()
        dict_res[lab] = dict(b=float(t['Estimate']), se=float(t['Std. Error']), p=float(t['Pr(>|t|)']), n=int(m._N),
                             k=int(z['name'].nunique()), pre_mean_treat=float(z.loc[(z.treat == 1) & (z.post == 0), 'tone_yao'].mean()),
                             b_sd=float(t['Estimate'] / sd), ci_sd=[float((t['Estimate'] - 1.96 * t['Std. Error']) / sd),
                                                                   float((t['Estimate'] + 1.96 * t['Std. Error']) / sd)],
                             wcb_p=wcr(z, 'tone_yao', reps=a.reps))
        print('tone_yao', lab, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in dict_res[lab].items()}, flush=True)
    res['dict_tone_same_sample'] = dict_res
    # 事件研究：k = -3..2，参照组 k = -1
    z = d[(d['china_focus'] == 1) & d['stance'].notna()].copy()
    ks = sorted(k for k in z['k'].unique() if k != -1)
    for k in ks: z[f'e{k + 10}'] = ((z['k'] == k) & (z['treat'] == 1)).astype(int)
    m = pf.feols(f"stance ~ {'+'.join(f'e{k + 10}' for k in ks)} + lntok | name + ym", data=z, vcov={'CRV1': 'name'})
    t = m.tidy()
    pre = [f'e{k + 10}' for k in ks if k < -1]
    bp = m.coef()[pre].values
    idx = [list(m.coef().index).index(c) for c in pre]; Vp = m._vcov[np.ix_(idx, idx)]
    from scipy import stats
    W = float(bp @ np.linalg.inv(Vp) @ bp); res['event_stance_pretrend'] = dict(wald=W, df=len(pre), p=float(stats.chi2.sf(W, len(pre))))
    res['event_stance_n'] = int(m._N)
    res['event_stance'] = [dict(k=int(k), b=float(t.loc[f'e{k + 10}', 'Estimate']), lo=float(t.loc[f'e{k + 10}', '2.5%']),
                                hi=float(t.loc[f'e{k + 10}', '97.5%'])) for k in ks]
    # 与词典语调的相关，用来说明两类指标测的是否是同一件事
    res['corr_with_dict_tone'] = float(d[['stance', 'tone_yao']].corr(method='spearman').iloc[0, 1])
    json.dump(res, open('llm_results.json', 'w'), indent=1, ensure_ascii=False)
    print('相关系数（大模型立场 vs 词典语调）', round(res['corr_with_dict_tone'], 3))
    print('结果已写入 llm_results.json')


# ------------------------------------------------------------------ inter-model agreement
def kappa_bin(x, y):
    x = np.asarray(x, int); y = np.asarray(y, int); po = (x == y).mean()
    pe = x.mean() * y.mean() + (1 - x.mean()) * (1 - y.mean())
    return float((po - pe) / (1 - pe)) if pe < 1 else float('nan')


def cmd_agree(a):
    """两个模型编码的一致性：有序变量报告精确一致、相差不超过 1、二次加权 kappa、Spearman；
    二元变量报告一致率和 Cohen's kappa；并检验两模型差异是否与处理×事后相关。"""
    import statsmodels.formula.api as smf
    A = load_scores(a.a); B = load_scores(a.b); s = pd.read_pickle(SAMPLE)[['aid', 'treat', 'post']]
    d = A.merge(B, on='aid', suffixes=('_a', '_b')).merge(s, on='aid')
    res = {'n': int(len(d)), 'model_a': sorted(A['model'].unique()), 'model_b': sorted(B['model'].unique()),
           'cells': {f'treat{t}_post{q}': int(n) for (t, q), n in d.groupby(['treat', 'post']).size().items()}}
    na, nb = d['stance_a'].isna(), d['stance_b'].isna()
    res['stance_null_agree'] = float((na == nb).mean())
    res['stance_null_rate'] = [float(na.mean()), float(nb.mean())]
    for v, lo, hi in [('stance', -2, 2), ('risk_emphasis', 0, 2), ('hedging', 0, 2), ('policy_endorsement', -1, 1)]:
        z = d[[f'{v}_a', f'{v}_b', 'treat', 'post']].dropna()
        diff = z[f'{v}_b'] - z[f'{v}_a']
        r = dict(n=int(len(z)), exact=float((diff == 0).mean()), within1=float((diff.abs() <= 1).mean()),
                 qwk=float(qwk(z[f'{v}_a'], z[f'{v}_b'], lo, hi)),
                 spearman=float(z[f'{v}_a'].corr(z[f'{v}_b'], method='spearman')),
                 mean_a=float(z[f'{v}_a'].mean()), mean_b=float(z[f'{v}_b'].mean()))
        z = z.assign(diff=diff, tp=z['treat'] * z['post'])
        fit = smf.ols('diff ~ treat + post + tp', data=z).fit(cov_type='HC1')
        r['diff_tp_coef'] = float(fit.params['tp']); r['diff_tp_se'] = float(fit.bse['tp']); r['diff_tp_p'] = float(fit.pvalues['tp'])
        r['exact_by_cell'] = {f'treat{t}_post{q}': round(float(v), 3) for (t, q), v in
                              z.assign(e=(z['diff'] == 0)).groupby(['treat', 'post'])['e'].mean().items()}
        res[v] = r
    for v in ['china_focus'] + [c[:-2] for c in d.columns if c.startswith('topic_') and c.endswith('_a')]:
        z = d[[f'{v}_a', f'{v}_b']].dropna()
        res[v] = dict(n=int(len(z)), agree=float((z[f'{v}_a'] == z[f'{v}_b']).mean()),
                      kappa=kappa_bin(z[f'{v}_a'], z[f'{v}_b']),
                      prev=[float(z[f'{v}_a'].mean()), float(z[f'{v}_b'].mean())])
    json.dump(res, open('llm_agreement.json', 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
    print(json.dumps(res, indent=1, ensure_ascii=False))


def cmd_robust(a):
    """6.5 节引用的补充检验：China focus 的 DID、全部有立场文章、剔除回填帖、剔除统计免责套话、Holm 校正。"""
    import pyfixest as pf
    sc = load_scores(a.scores); s = pd.read_pickle(SAMPLE)
    d = s.merge(sc, on='aid', how='inner'); d['tp'] = d['treat'] * d['post']; d['ym'] = d['date'].dt.strftime('%Y-%m')
    def est(z, y, boot=False):
        z = z[z[y].notna()].reset_index(drop=True)
        m = pf.feols(f'{y} ~ tp + lntok | name + ym', data=z, vcov={'CRV1': 'name'}); t = m.tidy().loc['tp']
        r = dict(b=float(t['Estimate']), se=float(t['Std. Error']), p=float(t['Pr(>|t|)']), n=int(m._N))
        if boot: r['wcb_p'] = wcr(z, y, reps=a.reps)
        return r
    china = (d['china_focus'] == 1) & d['stance'].notna()
    disc = d['prompt_text'].str.contains('统计误差|统计或者处理|数据统计存在误差|统计口径等影响')
    res = {'china_focus': est(d, 'china_focus', boot=True),
           'china_focus_drop_backfill': est(d[d['backfill'] == 0], 'china_focus'),
           'stance_all_with_code': est(d[d['stance'].notna()], 'stance'),
           'stance_drop_backfill': est(d[china & (d['backfill'] == 0)], 'stance'),
           'data_quality_excl_disclaimer': est(d[~disc], 'topic_data_quality'),
           'n_disclaimer': int(disc.sum()),
           'dq_rate_with_disclaimer': float(d.loc[disc, 'topic_data_quality'].mean()),
           'dq_rate_without': float(d.loc[~disc, 'topic_data_quality'].mean()),
           'china_share_by_quarter': {f'{g}|{q}': round(float(v), 3) for (g, q), v in
               d.assign(q=d['date'].dt.to_period('Q').astype(str)).groupby(['treat', 'q'])['china_focus'].mean().items()}}
    base = json.load(open('llm_results.json', encoding='utf-8'))['baseline']
    ps = sorted((v['p'], k) for k, v in base.items()); run = 0; holm = {}
    for i, (pv, k) in enumerate(ps): run = max(run, min(1.0, (len(ps) - i) * pv)); holm[k] = run
    res['holm_p'] = holm
    json.dump(res, open('llm_robustness.json', 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
    print(json.dumps({k: v for k, v in res.items() if k != 'china_share_by_quarter'}, indent=1, ensure_ascii=False))


def build_gold():
    """两位编码员的平均值作为人工标准。stance：两人都给分取平均；只有一人给分取该值；都为 NA 记为缺失。
    另建 stance0（NA 记 0，即“无方向判断”），供 DSL 使用。"""
    A, B = read_coder('human_coding_A.xlsx'), read_coder('human_coding_B.xlsx')
    key = pd.read_csv(HUMAN_KEY, encoding='utf-8-sig')
    g = A[['hid']].copy()
    for c in HUMAN_COLS:
        g['h_' + c] = pd.concat([A[c], B[c]], axis=1).mean(axis=1)          # 均值忽略 NA
    g['h_stance0'] = (A['stance'].fillna(0) + B['stance'].fillna(0)) / 2
    g['h_stance_bothna'] = A['stance_na'] & B['stance_na']
    return g.merge(key, on='hid'), A, B


def cmd_validate_mean(a):
    """以两人平均值为标准：编码员间一致性、模型对每位编码员的一致性、模型对平均值的误差检验。"""
    import statsmodels.formula.api as smf
    g, A, B = build_gold()
    sc = load_scores(a.scores); smp = pd.read_pickle(SAMPLE)[['aid', 'name']]
    d = g.merge(sc, on='aid').merge(smp, on='aid')
    Ai, Bi = A.set_index('hid').loc[d['hid']].reset_index(), B.set_index('hid').loc[d['hid']].reset_index()
    res = {'n': int(len(d)), 'gold': 'mean of two coders',
           'inter_coder': {'stance_na_agree': float((A['stance_na'] == B['stance_na']).mean())},
           'model_vs_human': {'stance_na_agree_A': float((Ai['stance_na'].values == d['stance'].isna().values).mean()),
                              'stance_na_agree_B': float((Bi['stance_na'].values == d['stance'].isna().values).mean()),
                              'model_china_stance_null': int(((d['china_focus'] == 1) & d['stance'].isna()).sum()),
                              'human_china_stance_na': [int(((A['china_focus'] == 1) & A['stance_na']).sum()),
                                                        int(((B['china_focus'] == 1) & B['stance_na']).sum())]}}
    for c in HUMAN_COLS:
        res['inter_coder'][c] = agree_stats(A[c], B[c], c)
        m = d[MODEL_COL[c]]
        r = dict(vs_A=agree_stats(m, Ai[c], c), vs_B=agree_stats(m, Bi[c], c))
        z = pd.DataFrame({'err': m - d['h_' + c], 'treat': d['treat'], 'post': d['post'], 'name': d['name']}).dropna()
        z['tp'] = z['treat'] * z['post']
        fit = smf.ols('err ~ treat + post + tp', data=z).fit(cov_type='cluster', cov_kwds={'groups': pd.factorize(z['name'])[0]})
        r.update(n=int(len(z)), mean_err=float(z['err'].mean()), mae=float(z['err'].abs().mean()),
                 err_tp=float(fit.params['tp']), err_tp_se=float(fit.bse['tp']), err_tp_p=float(fit.pvalues['tp']))
        res['model_vs_human'][c] = r
    json.dump(res, open('llm_validation.json', 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
    for c in HUMAN_COLS:
        x = res['model_vs_human'][c]; st = 'qwk' if c in SCALE else 'kappa'
        print(f"{c:14s} inter {res['inter_coder'][c].get(st, float('nan')):.2f} | model-A {x['vs_A'].get(st, float('nan')):.2f} "
              f"model-B {x['vs_B'].get(st, float('nan')):.2f} | err_tp {x['err_tp']:.3f} ({x['err_tp_se']:.3f}) p={x['err_tp_p']:.3f} n={x['n']}")


def cmd_dsl(a):
    """设计型监督学习（DSL，Egami et al. 2023）校正：伪结果 = 模型编码 + (是否人工抽中 / 抽中概率) × (人工 − 模型)，
    再用与表 9 相同的 DID 设定估计。抽样按处理组×前后期分层，每层 50 篇，抽中概率已知。"""
    import pyfixest as pf
    g, _, _ = build_gold()
    sc = load_scores(a.scores); s = pd.read_pickle(SAMPLE)
    d = s.merge(sc, on='aid', how='inner').merge(g.drop(columns=['treat', 'post']), on='aid', how='left')
    d['tp'] = d['treat'] * d['post']; d['ym'] = d['date'].dt.strftime('%Y-%m')
    d['R'] = d['hid'].notna().astype(int)
    cell = d.groupby(['treat', 'post'])['R'].agg(['sum', 'size'])
    d['pi'] = d.set_index(['treat', 'post']).index.map(lambda t: cell.loc[t, 'sum'] / cell.loc[t, 'size'])
    print('抽中概率：', {f'treat{t}_post{q}': round(v['sum'] / v['size'], 4) for (t, q), v in cell.iterrows()})
    outs = [('stance', 'stance', 'h_stance0'), ('china_focus', 'china_focus', 'h_china_focus'),
            ('risk_emphasis', 'risk_emphasis', 'h_risk_emphasis'), ('policy_endorsement', 'policy_endorsement', 'h_policy')] + \
           [(v, v, 'h_' + k) for k, v in TOPIC_MAP.items()]
    res = {}
    for lab, ycol, hcol in outs:
        z = d.copy()
        if lab == 'stance':
            z = z[(z['china_focus'] == 1) & z['stance'].notna()]
        z = z[z[ycol].notna()].copy()
        z['dsl'] = z[ycol] + np.where(z['R'] == 1, (z[hcol].fillna(z[ycol]) - z[ycol]) / z['pi'], 0.0)
        z = z.reset_index(drop=True); r = {}
        for y in [ycol, 'dsl']:
            m = pf.feols(f'{y} ~ tp + lntok | name + ym', data=z, vcov={'CRV1': 'name'}); t = m.tidy().loc['tp']
            sd = z.loc[z['post'] == 0, ycol].std()
            r[('naive' if y == ycol else 'dsl')] = dict(b=float(t['Estimate']), se=float(t['Std. Error']), p=float(t['Pr(>|t|)']),
                                                         n=int(m._N), b_sd=float(t['Estimate'] / sd),
                                                         ci_sd=[float((t['Estimate'] - 1.96 * t['Std. Error']) / sd),
                                                                float((t['Estimate'] + 1.96 * t['Std. Error']) / sd)])
        r['dsl']['wcb_p'] = wcr(z, 'dsl', reps=a.reps)
        r['n_human'] = int(z['R'].sum())
        res[lab] = r
        print(f"{lab:20s} naive {r['naive']['b']:.3f} ({r['naive']['se']:.3f}) | DSL {r['dsl']['b']:.3f} ({r['dsl']['se']:.3f}) "
              f"p={r['dsl']['p']:.3f} wcb={r['dsl']['wcb_p']:.3f} SD={r['dsl']['b_sd']:.2f} CI_SD=[{r['dsl']['ci_sd'][0]:.2f},{r['dsl']['ci_sd'][1]:.2f}] "
              f"human n={r['n_human']}", flush=True)
    json.dump(res, open('llm_dsl.json', 'w', encoding='utf-8'), indent=1, ensure_ascii=False)


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest='cmd', required=True)
    x = sp.add_parser('sample'); x.add_argument('--start', default=WINDOW_START)
    x = sp.add_parser('score'); x.add_argument('--provider', default='deepseek', choices=list(PROVIDERS))
    x.add_argument('--model'); x.add_argument('--limit', type=int); x.add_argument('--workers', type=int, default=4)
    x.add_argument('--sleep', type=float, default=0); x.add_argument('--out')
    x.add_argument('--subsample', type=int, help='分层随机抽取 N 篇（第二个模型一致性检验用）')
    x.add_argument('--seed', type=int, default=2026)
    x = sp.add_parser('validate-mean'); x.add_argument('--scores', default=SCORES)
    x = sp.add_parser('dsl'); x.add_argument('--scores', default=SCORES); x.add_argument('--reps', type=int, default=1999)
    x = sp.add_parser('robust'); x.add_argument('--scores', default=SCORES); x.add_argument('--reps', type=int, default=1999)
    x = sp.add_parser('agree'); x.add_argument('--a', default=SCORES); x.add_argument('--b', required=True)
    x = sp.add_parser('export-human'); x.add_argument('--n', type=int, default=200)
    x = sp.add_parser('validate'); x.add_argument('--scores', default=SCORES)
    x = sp.add_parser('did'); x.add_argument('--scores', default=SCORES); x.add_argument('--reps', type=int, default=1999)
    a = ap.parse_args()
    {'sample': cmd_sample, 'score': cmd_score, 'export-human': cmd_export_human,
     'validate': cmd_validate, 'did': cmd_did, 'agree': cmd_agree, 'robust': cmd_robust, 'validate-mean': cmd_validate_mean, 'dsl': cmd_dsl}[a.cmd](a)
